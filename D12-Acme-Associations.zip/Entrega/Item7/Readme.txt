Los tests se han realizado entre 3 grupos formando un tri�ngulo por lo tanto los dos
outbound reports son de grupos diferentes al igual que los inbound.

